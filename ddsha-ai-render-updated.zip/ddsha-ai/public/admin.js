'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = t => t ? new Date(t).toLocaleString('ru-RU') : '—';
async function api(m, u, b) {
  const r = await fetch('/api/admin' + u, { method: m, headers: b ? { 'Content-Type': 'application/json' } : {}, body: b ? JSON.stringify(b) : undefined, credentials: 'same-origin' });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || 'Ошибка ' + r.status); return d;
}
const fail = e => { $('#err').textContent = e.message; };
let plans = [];
const views = {
  async stats() {
    const s = await api('GET', '/stats');
    $('#view').innerHTML = `<div class="grid">${[['Пользователи', s.users], ['Заблокировано', s.blocked], ['Чатов', s.chats], ['Сообщений', s.messages], ['Запросов сегодня', s.messagesToday]].map(x => `<div class="card stat"><span class="mu">${x[0]}</span><b>${x[1]}</b></div>`).join('')}</div>
    <h3>По тарифам</h3>${s.byPlan.map(x => `<span class="badge">${esc(x.plan)}: ${x.c}</span> `).join('')}<p class="mu">БД: ${esc(s.db)}</p>`;
  },
  async users() {
    $('#view').innerHTML = `<div class="row"><input id="q" placeholder="Поиск: ID, имя или email"><button class="btn pri" id="go">Найти</button></div><div class="tw" id="ul"></div><div id="ud"></div>`;
    const load = async () => {
      const { users } = await api('GET', '/users?q=' + encodeURIComponent($('#q').value));
      $('#ul').innerHTML = `<table><tr><th>ID</th><th>Имя</th><th>Email</th><th>Тариф</th><th>Статус</th><th></th></tr>${users.map(u => `<tr><td>${u.id}</td><td>${esc(u.username)}</td><td>${esc(u.email)}</td><td>${esc(u.role === 'owner' ? 'ALL (владелец)' : u.plan)}</td><td><span class="badge ${u.status === 'blocked' ? 'bad' : ''}">${u.status}</span></td><td><button class="btn sm" data-id="${u.id}">Открыть</button></td></tr>`).join('')}</table>`;
    };
    $('#go').onclick = () => load().catch(fail); $('#q').onkeydown = e => e.key === 'Enter' && load().catch(fail); await load();
    $('#ul').onclick = e => e.target.dataset.id && openUser(e.target.dataset.id).catch(fail);
  },
  async plans() {
    plans = (await api('GET', '/plans')).plans;
    $('#view').innerHTML = plans.map(p => `<form class="pf card" data-id="${p.id}"><b>${esc(p.name)}</b> <span class="mu">(${p.id})</span><div class="f2">
      <label>Сообщений/день<input name="msgPerDay" type="number" min="0" value="${p.msgPerDay}"></label><label>Макс. символов<input name="maxChars" type="number" min="100" value="${p.maxChars}"></label>
      <label>Модели (через запятую, * = все)<input name="models" value="${esc((p.models || []).join(','))}"></label><label>Изображений/день<input name="imagesPerDay" type="number" min="0" value="${p.imagesPerDay}"></label><label>Видео/день<input name="videosPerDay" type="number" min="0" value="${p.videosPerDay}"></label></div>
      <div class="f2">${['files:Файлы', 'search:Поиск', 'thinking:Thinking', 'research:Research'].map(x => { const [k, l] = x.split(':'); return `<label class="ck"><input type="checkbox" name="${k}" ${p[k] ? 'checked' : ''}>${l}</label>`; }).join('')}</div>
      <button class="btn pri sm">Сохранить</button> <span class="ok"></span></form><br>`).join('') + '<p class="mu">Лимиты изображений/видео сохраняются, но генерация изображений и видео пока не подключена к провайдеру.</p>';
    document.querySelectorAll('.pf').forEach(f => f.onsubmit = async e => {
      e.preventDefault(); const d = new FormData(f), o = { models: String(d.get('models')).split(',').map(s => s.trim()).filter(Boolean) };
      for (const k of ['msgPerDay', 'maxChars', 'imagesPerDay', 'videosPerDay']) o[k] = Number(d.get(k));
      for (const k of ['files', 'search', 'thinking', 'research']) o[k] = d.get(k) === 'on';
      try { await api('PUT', '/plans/' + f.dataset.id, o); f.querySelector('.ok').textContent = 'Сохранено ✓'; } catch (er) { fail(er); }
    });
  },
  async audit() {
    const { items } = await api('GET', '/audit');
    $('#view').innerHTML = `<div class="tw"><table><tr><th>Время</th><th>Админ</th><th>Действие</th><th>Цель</th><th>Детали</th></tr>${items.map(a => `<tr><td>${fmt(a.created)}</td><td>${esc(a.actor)}</td><td>${esc(a.action)}</td><td>${esc(a.target)}</td><td>${esc(a.detail)}</td></tr>`).join('')}</table></div>`;
  },
  async settings() {
    const s = await api('GET', '/settings');
    $('#view').innerHTML = `<label class="row"><span>Регистрация новых пользователей открыта</span><input type="checkbox" id="reg" ${s.registration_open ? 'checked' : ''}></label><p>Дополнительная системная инструкция для ИИ</p><textarea id="note" rows="4" maxlength="1000">${esc(s.system_note)}</textarea><br><br><button class="btn pri" id="save">Сохранить</button> <span class="ok" id="sok"></span>`;
    $('#save').onclick = async () => { try { await api('PUT', '/settings', { registration_open: $('#reg').checked, system_note: $('#note').value }); $('#sok').textContent = 'Сохранено ✓'; } catch (e) { fail(e); } };
  }
};
async function openUser(id) {
  const [{ user: u }] = [await api('GET', '/users/' + id)]; plans = plans.length ? plans : (await api('GET', '/plans')).plans;
  $('#ud').innerHTML = `<div class="card"><h3>${esc(u.username)} <span class="badge ${u.status === 'blocked' ? 'bad' : ''}">${u.status}</span></h3><div class="kv"><span>ID</span><span>${u.id}</span><span>Email</span><span>${esc(u.email)}</span><span>Регистрация</span><span>${fmt(u.created)}</span><span>Тариф</span><span>${esc(u.planName)}${u.planUntil ? ' до ' + fmt(u.planUntil) : ''}</span><span>Чатов / сегодня</span><span>${u.chats} / ${u.usedToday} сообщ.</span></div>
  ${u.role === 'owner' ? '<p class="mu">Владелец — изменения недоступны.</p>' : `<div class="row"><select id="pl">${plans.map(p => `<option value="${p.id}" ${p.id === u.plan ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select><input id="days" type="number" min="1" max="3650" placeholder="Дней (пусто = бессрочно)"><button class="btn pri" id="setp">Выдать / сменить</button></div><br>
  <div class="row end"><button class="btn" id="rev">Снять тариф</button><button class="btn ${u.status === 'blocked' ? '' : 'dng'}" id="blk">${u.status === 'blocked' ? 'Разблокировать' : 'Заблокировать'}</button></div>`}</div>`;
  if (u.role === 'owner') return;
  const act = async (path, b) => { try { await api('POST', `/users/${id}/${path}`, b); $('#err').textContent = ''; await openUser(id); if ($('#go')) $('#go').click(); } catch (e) { fail(e); } };
  $('#setp').onclick = () => act('plan', { plan: $('#pl').value, days: $('#days').value || null });
  $('#rev').onclick = () => act('plan', { plan: 'free' });
  $('#blk').onclick = () => { if (u.status === 'blocked') act('block', { blocked: false }); else { const r = prompt('Причина блокировки (необязательно)'); if (r !== null) act('block', { blocked: true, reason: r }); } };
}
document.querySelectorAll('#nav button').forEach(b => b.onclick = () => { document.querySelectorAll('#nav button').forEach(x => x.classList.toggle('on', x === b)); $('#err').textContent = ''; views[b.dataset.s]().catch(fail); });
views.stats().catch(e => { $('#view').innerHTML = '<p>Доступ только для владельца. <a href="/">Войдите</a> под аккаунтом владельца.</p>'; fail(e); });
