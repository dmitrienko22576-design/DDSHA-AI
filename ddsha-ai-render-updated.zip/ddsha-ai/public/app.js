'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
async function api(m, u, b) {
  const r = await fetch('/api' + u, { method: m, headers: b ? { 'Content-Type': 'application/json' } : {}, body: b ? JSON.stringify(b) : undefined, credentials: 'same-origin' });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || 'Ошибка ' + r.status), { status: r.status });
  return d;
}
function md(s) {
  return s.split('```').map((p, i) => {
    if (i % 2) { const n = p.indexOf('\n'), lang = n < 0 ? '' : p.slice(0, n).trim(), code = (n < 0 ? p : p.slice(n + 1)).replace(/\n$/, '');
      return `<div class="code"><div class="ch"><span>${esc(lang || 'code')}</span><button class="cp">Копировать</button></div><pre><code>${esc(code)}</code></pre></div>`; }
    return esc(p).replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>').replace(/^#{1,3} (.+)$/gm, '<h4>$1</h4>')
      .replace(/(https?:\/\/[^\s<)]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>').replace(/\n/g, '<br>');
  }).join('');
}
let me, info, chats = [], cur = null, msgs = [], mode = 'fast', ctl = null, file = null, authTab = 'login';

// ---------- авторизация ----------
function showAuth(t, msg = '') {
  authTab = t; $('#app').hidden = true; $('#auth').hidden = false; $('#aerr').textContent = msg; $('#aerr').className = 'err';
  document.querySelectorAll('.fm').forEach(f => f.hidden = f.dataset.t !== t);
  $('#atabs').hidden = t === 'forgot' || t === 'reset';
  document.querySelectorAll('#atabs button').forEach(b => b.classList.toggle('on', b.dataset.t === t));
}
document.querySelectorAll('#atabs button').forEach(b => b.onclick = () => showAuth(b.dataset.t));
$('#toForgot').onclick = e => { e.preventDefault(); showAuth('forgot'); };
$('#toLogin').onclick = e => { e.preventDefault(); showAuth('login'); };
function form(id, path, after) {
  $(id).onsubmit = async e => {
    e.preventDefault(); const btn = e.target.querySelector('button.pri'); btn.disabled = true;
    try { const d = await api('POST', path, Object.fromEntries(new FormData(e.target))); await after(d, e.target); }
    catch (er) { $('#aerr').className = 'err'; $('#aerr').textContent = er.message; } finally { btn.disabled = false; }
  };
}
form('#fLogin', '/login', () => boot()); form('#fRegister', '/register', () => boot());
form('#fForgot', '/forgot', d => { $('#aerr').className = 'ok'; $('#aerr').textContent = d.message; });
$('#fReset').onsubmit = async e => {
  e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
  try { await api('POST', '/reset', { ...f, token: new URLSearchParams(location.search).get('reset') }); history.replaceState(null, '', '/'); showAuth('login'); $('#aerr').className = 'ok'; $('#aerr').textContent = 'Пароль изменён. Войдите.'; }
  catch (er) { $('#aerr').className = 'err'; $('#aerr').textContent = er.message; }
};

// ---------- запуск ----------
async function boot() {
  try { info = await api('GET', '/me'); } catch (e) { if (e.status === 401) return showAuth(new URLSearchParams(location.search).get('reset') ? 'reset' : 'login'); return showAuth('login', e.message); }
  me = info.user; $('#auth').hidden = true; $('#app').hidden = false;
  $('#av').textContent = me.username[0].toUpperCase(); $('#pName').textContent = me.username; $('#pPlan').textContent = 'Тариф: ' + me.planName;
  $('#adminLink').hidden = me.role !== 'owner';
  const sel = $('#model'); sel.innerHTML = info.models.map(m => `<option>${esc(m)}</option>`).join('');
  if (me.settings.model && info.models.includes(me.settings.model)) sel.value = me.settings.model;
  document.querySelectorAll('#modes button').forEach(b => { const m = b.dataset.m; b.disabled = (m === 'thinking' && !info.plan.thinking) || (m === 'research' && (!info.plan.research || !info.features.research)); b.title = b.disabled ? 'Недоступно на вашем тарифе или не настроено' : ''; });
  if (mode !== 'fast' && document.querySelector(`#modes [data-m=${mode}]`).disabled) setMode('fast');
  updHint(); await loadChats(); if (!cur) newChat(true);
}
function updHint() { $('#hint').textContent = `Сегодня: ${info.usedToday} / ${info.plan.msgPerDay} сообщений · ${info.features.ai ? 'ИИ работает на внешней модели' : '⚠ ИИ-провайдер не настроен'}`; $('#attach').hidden = !info.plan.files; }
function setMode(m) { mode = m; document.querySelectorAll('#modes button').forEach(b => b.classList.toggle('on', b.dataset.m === m)); }
document.querySelectorAll('#modes button').forEach(b => b.onclick = () => !b.disabled && setMode(b.dataset.m));
$('#model').onchange = e => api('PATCH', '/me/settings', { model: e.target.value }).catch(() => {});

// ---------- чаты ----------
async function loadChats() { chats = (await api('GET', '/chats')).chats; renderChats(); }
function renderChats() {
  $('#chats').innerHTML = chats.map(c => `<div class="ci ${c.id === cur ? 'on' : ''}" data-id="${c.id}"><span>${esc(c.title || 'Новый чат')}</span><button data-a="ren" title="Переименовать">✎</button><button data-a="del" title="Удалить">🗑</button></div>`).join('');
}
$('#chats').onclick = async e => {
  const ci = e.target.closest('.ci'); if (!ci) return; const id = ci.dataset.id, a = e.target.dataset.a;
  try {
    if (a === 'ren') { const t = prompt('Новое название', chats.find(c => c.id === id).title); if (t && t.trim()) { await api('PATCH', '/chats/' + id, { title: t }); await loadChats(); } }
    else if (a === 'del') { if (confirm('Удалить чат?')) { await api('DELETE', '/chats/' + id); if (cur === id) cur = null; await loadChats(); if (!cur) newChat(true); } }
    else { await openChat(id); closeSide(); }
  } catch (er) { alert(er.message); }
};
async function newChat(local) {
  if (local === true) { cur = null; msgs = []; renderMsgs(); renderChats(); return; }
  cur = null; msgs = []; renderMsgs(); renderChats(); closeSide(); $('#prompt').focus();
}
$('#newChat').onclick = () => newChat();
async function openChat(id) { cur = id; msgs = (await api('GET', `/chats/${id}/messages`)).messages; renderChats(); renderMsgs(); }
function bubble(m, i) {
  const u = m.role === 'user';
  return `<div class="m ${u ? 'u' : 'a'}"><div class="bub">${u ? esc(m.content) : md(m.content)}</div>${u ? '' : `<div class="act"><button data-cp="${i}">Копировать</button></div>`}</div>`;
}
function renderMsgs() {
  $('#wrap').innerHTML = msgs.length ? msgs.map(bubble).join('') : `<div class="hero"><div class="logo hl"><i>D</i></div><h1>Привет, ${esc(me ? me.username : '')}!</h1><p class="mu">Я DDSHA AI. Спросите что угодно, разберём код или текст.</p><div class="chips"><button data-p="Объясни, как работает async/await в JavaScript">💻 Помощь с кодом</button><button data-p="Помоги составить план проекта на неделю">🗂 План</button><button data-p="Придумай идею для короткого мультфильма">🎬 Идея</button></div></div>`;
  $('#msgs').scrollTop = $('#msgs').scrollHeight;
}
$('#wrap').onclick = e => {
  if (e.target.dataset.p) return send(e.target.dataset.p);
  if (e.target.classList.contains('cp')) return copy(e.target, e.target.closest('.code').querySelector('code').textContent);
  if (e.target.dataset.cp) return copy(e.target, msgs[+e.target.dataset.cp].content);
};
async function copy(btn, t) { try { await navigator.clipboard.writeText(t); const o = btn.textContent; btn.textContent = 'Скопировано ✓'; setTimeout(() => btn.textContent = o, 1400); } catch { prompt('Скопируйте:', t); } }

// ---------- отправка и потоковый ответ ----------
const P = $('#prompt'), S = $('#send');
function busy(b) { S.textContent = b ? '■' : '➤'; S.setAttribute('aria-label', b ? 'Остановить' : 'Отправить'); }
async function send(text) {
  text = (text || '').trim(); if (!text || ctl) return;
  if (!cur) { try { cur = (await api('POST', '/chats')).id; } catch (e) { return alert(e.message); } }
  const payload = { content: text, mode, model: $('#model').value }; if (file) payload.file = file;
  msgs.push({ role: 'user', content: file ? `${text}\n\n📎 ${file.name}` : text }); const a = { role: 'assistant', content: '' }; msgs.push(a);
  P.value = ''; resize(); file = null; $('#fileTag').hidden = true; renderMsgs();
  const last = () => $('#wrap').lastElementChild.querySelector('.bub'); last().innerHTML = '<span class="dots"><i></i><i></i><i></i></span>';
  ctl = new AbortController(); busy(true);
  try {
    const r = await fetch(`/api/chats/${cur}/stream`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), signal: ctl.signal, credentials: 'same-origin' });
    if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.error || 'Ошибка ' + r.status); }
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
    for (;;) {
      const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true }); let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 2); if (!line.startsWith('data:')) continue;
        const ev = JSON.parse(line.slice(5)); if (ev.error) throw new Error(ev.error);
        if (ev.t) { a.content += ev.t; last().innerHTML = md(a.content); const m = $('#msgs'); if (m.scrollHeight - m.scrollTop - m.clientHeight < 140) m.scrollTop = m.scrollHeight; }
      }
    }
  } catch (e) {
    if (e.name !== 'AbortError') { a.content += (a.content ? '\n\n' : '') + '⚠ ' + e.message; last().innerHTML = md(a.content); if (!a.content.replace('⚠ ' + e.message, '').trim()) a.err = true; }
  } finally {
    ctl = null; busy(false); renderMsgs();
    try { info = await api('GET', '/me'); updHint(); await loadChats(); } catch {}
  }
}
S.onclick = () => ctl ? ctl.abort() : send(P.value);
P.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(P.value); } });
function resize() { P.style.height = 'auto'; P.style.height = Math.min(P.scrollHeight, 160) + 'px'; }
P.addEventListener('input', resize);
$('#attach').onclick = () => $('#fileIn').click();
$('#fileIn').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  if (f.size > 300000) return alert('Файл слишком большой (максимум 300 КБ текста)');
  const text = await f.text(); if (text.includes('\u0000')) return alert('Поддерживаются только текстовые файлы (TXT, MD, CSV, код). PDF и изображения пока не поддерживаются.');
  file = { name: f.name, text }; $('#fileTag').hidden = false; $('#fileTag').textContent = '📎 ' + f.name + ' (' + text.length + ' симв.) — нажмите, чтобы убрать';
};
$('#fileTag').onclick = () => { file = null; $('#fileTag').hidden = true; };

// ---------- меню, профиль, память ----------
const closeSide = () => { $('#side').classList.remove('open'); $('#scrim').hidden = true; };
$('#menu').onclick = () => { $('#side').classList.add('open'); $('#scrim').hidden = false; }; $('#scrim').onclick = closeSide;
$('#dclose').onclick = () => $('#dlg').close();
$('#openSet').onclick = async () => {
  const fmt = t => t ? new Date(t).toLocaleDateString('ru-RU') : '—';
  const mem = (await api('GET', '/memory')).items, on = me.settings.memory !== false, pl = info.plan;
  $('#dbody').innerHTML = `<h3>Личный кабинет</h3><div class="kv"><span>ID</span><span>${esc(me.id)}</span><span>Имя</span><span>${esc(me.username)}</span><span>Email</span><span>${esc(me.email)}</span><span>Регистрация</span><span>${fmt(me.created)}</span><span>Тариф</span><span>${esc(me.planName)}${me.planUntil ? ' до ' + fmt(me.planUntil) : ''}</span><span>Статус</span><span>${me.status === 'active' ? 'Активен' : 'Заблокирован'}</span><span>Лимиты</span><span>${pl.msgPerDay} сообщ./день · Thinking: ${pl.thinking ? 'да' : 'нет'} · Research: ${pl.research ? 'да' : 'нет'} · файлы: ${pl.files ? 'да' : 'нет'}</span></div>
  <h3>Внешний вид</h3><label class="row"><span>Тема интерфейса</span><select id="themeSelect"><option value="system">Системная</option><option value="light">Светлая</option><option value="dark">Тёмная</option></select></label>
   <h3>Память</h3><label class="row"><span>Использовать память в чатах</span><input type="checkbox" id="memOn" ${on ? 'checked' : ''}></label>
  <div id="memList">${mem.map(x => `<div class="li"><span>${esc(x.text)}</span><button class="btn sm dng" data-d="${x.id}">Удалить</button></div>`).join('') || '<p class="mu">Пока пусто</p>'}</div>
  <div class="row"><input id="memNew" maxlength="300" placeholder="Что запомнить?"><button class="btn" id="memAdd">Добавить</button></div>
  <p class="mu">Модели — внешние (сторонний провайдер). Собственной обученной модели DDSHA пока нет.</p><div class="row end"><button class="btn dng" id="logout">Выйти</button></div>`;
  if(!$('#dlg').open)$('#dlg').showModal();
  $('#themeSelect').value = window.DDSHATheme ? DDSHATheme.get() : 'system';
   $('#themeSelect').onchange = e => { if (window.DDSHATheme) DDSHATheme.set(e.target.value); };
   $('#memOn').onchange = async e => { me.settings = (await api('PATCH', '/me/settings', { memory: e.target.checked })).settings; };
  $('#memAdd').onclick = async () => { const t = $('#memNew').value.trim(); if (!t) return; try { await api('POST', '/memory', { text: t }); $('#openSet').click(); } catch (e) { alert(e.message); } };
  $('#memList').onclick = async e => { if (e.target.dataset.d) { await api('DELETE', '/memory/' + e.target.dataset.d); $('#openSet').click(); } };
  $('#logout').onclick = async () => { await api('POST', '/logout', {}); $('#dlg').close(); cur = null; chats = []; showAuth('login'); };
};
boot();
