'use strict';
(() => {
  const KEY = 'ddsha_theme';
  let preference = localStorage.getItem(KEY) || 'system';
  const media = window.matchMedia('(prefers-color-scheme: dark)');
  function apply() {
    const dark = preference === 'dark' || (preference === 'system' && media.matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', dark ? '#17191f' : '#ffffff');
  }
  window.DDSHATheme = {
    get: () => preference,
    set(value) {
      if (!['light', 'dark', 'system'].includes(value)) return;
      preference = value;
      localStorage.setItem(KEY, value);
      apply();
    }
  };
  media.addEventListener?.('change', () => { if (preference === 'system') apply(); });
  apply();
})();
