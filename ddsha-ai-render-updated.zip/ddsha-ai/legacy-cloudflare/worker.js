const SYSTEM_PROMPT = `Ты — DDSHA AI, дружелюбный ИИ-собеседник проекта DDSHA. Отвечай на русском, если пользователь пишет по-русски. Будь доброжелательным, понятным и честным. Не утверждай, что ты человек. Если не знаешь ответа, скажи об этом. Не проси пароли, коды подтверждения или личные секреты.`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders() });
    }

    if (url.pathname === "/api/health") {
      return json({ ok: true, service: "DDSHA AI" });
    }

    if (url.pathname === "/api/chat" && request.method === "POST") {
      try {
        const body = await request.json();
        if (!Array.isArray(body.messages)) {
          return json({ error: "Неверный формат сообщений." }, 400);
        }

        const messages = body.messages
          .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
          .slice(-12)
          .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));

        if (!messages.length || messages[messages.length - 1].role !== "user") {
          return json({ error: "Напиши сообщение." }, 400);
        }

        const result = await env.AI.run("@cf/zai-org/glm-4.7-flash", {
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            ...messages
          ],
          max_tokens: 700
        });

        const reply = result?.response || result?.choices?.[0]?.message?.content;
        if (!reply) return json({ error: "Модель не вернула текст. Попробуй позже." }, 502);
        return json({ reply: String(reply) });
      } catch (error) {
        return json({ error: "Не удалось связаться с ИИ. Проверь настройки Cloudflare и лимит бесплатного тарифа." }, 502);
      }
    }

    if (env.ASSETS) return env.ASSETS.fetch(request);
    return json({ error: "Файл сайта не найден." }, 404);
  }
};

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
}
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...corsHeaders() }
  });
}
