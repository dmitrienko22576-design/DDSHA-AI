# DDSHA AI — Render Web Service

Node.js 22+ сервер (без Express, единственная зависимость — `pg`) + статический фронтенд из `public/`.
Исходный Cloudflare Worker сохранён в `legacy-cloudflare/`; его `/api/chat` перенесён в стриминговый маршрут,
а Workers AI доступен через OpenAI-совместимый endpoint Cloudflare (`CF_ACCOUNT_ID` + `CF_API_TOKEN`).

## Публикация на Render
1. Залейте проект в GitHub (корень репозитория = корень проекта, где `package.json`).
2. Render → New → Blueprint → выберите репозиторий (`render.yaml` создаст Web Service и PostgreSQL).
   Вручную: New → Web Service + New → PostgreSQL, затем в сервисе добавьте `DATABASE_URL` (Internal Database URL).
3. В Environment задайте переменные и нажмите Deploy.
4. Войдите под аккаунтом владельца → кнопка «Админ-панель».

ROOT DIRECTORY: пусто (корень репозитория)
BUILD COMMAND: `npm install --omit=dev`
START COMMAND: `npm start` (= `node src/server.js`, порт из `process.env.PORT`)
Health Check Path: `/api/health`

## Переменные окружения
Обязательные: `DATABASE_URL`, `NODE_ENV=production`, `OWNER_USERNAME`, `OWNER_EMAIL`, `OWNER_PASSWORD` (≥10 символов;
владелец создаётся при старте только если владельцев ещё нет) и ОДИН вариант ИИ: `AI_API_KEY` (+`AI_BASE_URL`)
или `CF_ACCOUNT_ID` + `CF_API_TOKEN`. `AI_MODELS` — модели через запятую (первая по умолчанию).
Необязательные: `TAVILY_API_KEY` (режим «Исследователь»), `RESEND_API_KEY` + `MAIL_FROM` + `PUBLIC_URL` (письма восстановления).
После первого входа удалите `OWNER_PASSWORD` из Environment.

## Локально
Экспортируйте переменные из `.env.example`, `npm install`, `npm start`. Без `DATABASE_URL` используется SQLite (`data.db`).

## Ограничения
- Не реализованы: анализ PDF/изображений, генерация изображений и видео (лимиты хранятся, провайдер не подключён), страница Model Lab.
  Модели внешние; собственной модели DDSHA нет.
- Rate-limit и защита от перебора — в памяти одного экземпляра.
- Без настройки почты письмо восстановления не отправляется.
- Ветка PostgreSQL (`pg`) в моей среде не запускалась (нет сети и Postgres); проверен SQLite-вариант с тем же SQL.

## Темы интерфейса
В личном кабинете доступен выбор «Светлая / Тёмная / Системная». Выбор сохраняется в localStorage браузера; системная тема автоматически реагирует на настройку устройства. Тема применяется и к админ-панели на этом же браузере.
