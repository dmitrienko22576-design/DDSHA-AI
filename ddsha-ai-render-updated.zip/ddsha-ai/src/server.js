'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const db = require('./db');
const PROD = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;
const PUB = path.join(__dirname, '..', 'public');
const now = () => Date.now();
const rid = () => now().toString(36).padStart(9, '0') + crypto.randomBytes(6).toString('hex');
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const DAY = 864e5;

// ---------- ИИ-провайдер (ключи только в переменных окружения сервера) ----------
function provider() {
  const e = process.env;
  if (e.AI_API_KEY) return { base: (e.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, ''), key: e.AI_API_KEY, cf: false };
  if (e.CF_ACCOUNT_ID && e.CF_API_TOKEN) return { base: `https://api.cloudflare.com/client/v4/accounts/${e.CF_ACCOUNT_ID}/ai/v1`, key: e.CF_API_TOKEN, cf: true };
  return null;
}
function models() {
  const p = provider(), def = p && p.cf ? '@cf/zai-org/glm-4.7-flash' : 'gpt-4o-mini';
  return (process.env.AI_MODELS || process.env.AI_MODEL || def).split(',').map(s => s.trim()).filter(Boolean);
}

// ---------- Тарифы ----------
const DEFAULT_PLANS = {
  free:   { name: 'Free',    msgPerDay: 15,    maxChars: 4000,  models: [],    files: false, search: false, thinking: false, research: false, imagesPerDay: 0,  videosPerDay: 0 },
  pro:    { name: 'Pro',     msgPerDay: 100,   maxChars: 8000,  models: [],    files: true,  search: false, thinking: false, research: false, imagesPerDay: 0,  videosPerDay: 0 },
  max:    { name: 'Max',     msgPerDay: 300,   maxChars: 12000, models: ['*'], files: true,  search: false, thinking: true,  research: false, imagesPerDay: 10, videosPerDay: 0 },
  deluxe: { name: 'Deluxe',  msgPerDay: 800,   maxChars: 20000, models: ['*'], files: true,  search: true,  thinking: true,  research: true,  imagesPerDay: 30, videosPerDay: 3 },
  maxpro: { name: 'MaxPro',  msgPerDay: 2000,  maxChars: 30000, models: ['*'], files: true,  search: true,  thinking: true,  research: true,  imagesPerDay: 100, videosPerDay: 10 },
  all:    { name: 'ALL (владелец)', msgPerDay: 1000000, maxChars: 60000, models: ['*'], files: true, search: true, thinking: true, research: true, imagesPerDay: 100000, videosPerDay: 100000 }
};
async function getPlans() {
  const o = {};
  for (const r of await db.q('select id,name,cfg from plans')) o[r.id] = { id: r.id, ...JSON.parse(r.cfg), name: r.name };
  return o;
}
const effPlanId = u => u.role === 'owner' ? 'all' : (u.plan !== 'free' && u.plan_until && u.plan_until < now() ? 'free' : u.plan);
const modelAllowed = (P, m) => models().includes(m) && (P.models.includes('*') || P.models.includes(m) || m === models()[0]);

// ---------- Утилиты ----------
const hits = new Map();
function limit(key, max, win) {
  const t = now(), a = (hits.get(key) || []).filter(x => t - x < win);
  if (a.length >= max) { hits.set(key, a); return false; }
  a.push(t); hits.set(key, a); return true;
}
setInterval(() => { const t = now(); for (const [k, a] of hits) if (!a.length || t - a[a.length - 1] > 36e5) hits.delete(k); }, 6e5).unref();
const ipOf = req => String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
function send(res, code, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(b);
}
async function body(req, max = 1.5e6) {
  let n = 0; const ch = [];
  for await (const c of req) { n += c.length; if (n > max) throw Object.assign(new Error('Слишком большой запрос'), { code: 413 }); ch.push(c); }
  if (!n) return {};
  try { const j = JSON.parse(Buffer.concat(ch).toString('utf8')); return j && typeof j === 'object' ? j : {}; }
  catch { throw Object.assign(new Error('Неверный JSON'), { code: 400 }); }
}
const cookies = req => Object.fromEntries(String(req.headers.cookie || '').split(';').map(s => s.trim().split(/=(.*)/s).slice(0, 2)).filter(a => a[0]));
function setCookie(res, token, maxAge) {
  res.setHeader('Set-Cookie', `ddsha_sid=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${PROD ? '; Secure' : ''}`);
}
async function hashPass(p) {
  const salt = crypto.randomBytes(16);
  const h = await new Promise((ok, no) => crypto.scrypt(p, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => e ? no(e) : ok(k)));
  return `s1$${salt.toString('hex')}$${h.toString('hex')}`;
}
async function checkPass(p, stored) {
  const [v, s, h] = String(stored).split('$'); if (v !== 's1') return false;
  const k = await new Promise((ok, no) => crypto.scrypt(p, Buffer.from(s, 'hex'), 64, { N: 16384, r: 8, p: 1 }, (e, k) => e ? no(e) : ok(k)));
  return crypto.timingSafeEqual(k, Buffer.from(h, 'hex'));
}
async function audit(actor, action, target, detail) {
  await db.q('insert into audit(id,actor,action,target,detail,created) values(?,?,?,?,?,?)', [rid(), actor, action, target || null, detail ? JSON.stringify(detail) : null, now()]);
}
async function setting(k, def = '') { const r = await db.q('select v from settings where k=?', [k]); return r[0] ? r[0].v : def; }
async function newSession(res, uid) {
  const token = crypto.randomBytes(32).toString('base64url');
  await db.q('insert into sessions(id,user_id,expires,created) values(?,?,?,?)', [sha(token), uid, now() + 30 * DAY, now()]);
  setCookie(res, token, 30 * 86400);
}
async function sessionUser(req) {
  const t = cookies(req).ddsha_sid; if (!t) return null;
  const r = await db.q('select u.* from sessions s join users u on u.id=s.user_id where s.id=? and s.expires>?', [sha(t), now()]);
  return r[0] || null;
}
const pub = (u, P) => ({ id: u.id, username: u.username, email: u.email, role: u.role, created: u.created, status: u.status, plan: effPlanId(u), planName: P ? P.name : effPlanId(u), planUntil: u.plan_until, settings: JSON.parse(u.settings || '{}') });
const fail = (code, msg) => Object.assign(new Error(msg), { code });

// ---------- Почта (Resend) ----------
async function sendMail(to, subject, html) {
  if (!process.env.RESEND_API_KEY || !process.env.MAIL_FROM) return false;
  const r = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: 'Bearer ' + process.env.RESEND_API_KEY, 'Content-Type': 'application/json' }, body: JSON.stringify({ from: process.env.MAIL_FROM, to, subject, html }) });
  return r.ok;
}

// ---------- Чат (потоковая генерация) ----------
const MODE_PROMPT = {
  fast: 'Режим «Быстрый»: отвечай коротко и по делу, без лишних рассуждений.',
  thinking: 'Режим «Думающий»: сначала внимательно разбери задачу по шагам, проверь промежуточные выводы и крайние случаи, затем дай чёткий итоговый ответ. Для кода — полный рабочий пример.',
  research: 'Режим «Исследователь»: опирайся ТОЛЬКО на приведённые источники, ссылайся на них номерами [1], [2]. Если данных недостаточно — прямо скажи об этом. Не выдумывай ссылки.'
};
async function tavily(query) {
  const r = await fetch('https://api.tavily.com/search', { method: 'POST', headers: { Authorization: 'Bearer ' + process.env.TAVILY_API_KEY, 'Content-Type': 'application/json' }, body: JSON.stringify({ query: query.slice(0, 400), max_results: 5 }), signal: AbortSignal.timeout(20000) });
  if (!r.ok) throw new Error('Поиск недоступен (' + r.status + ')');
  return ((await r.json()).results || []).slice(0, 5).map(x => ({ title: String(x.title || x.url), url: x.url, content: String(x.content || '').slice(0, 800) }));
}
async function streamChat(req, res, u, chatId, b) {
  const P = (await getPlans())[effPlanId(u)] || DEFAULT_PLANS.free;
  const chat = (await db.q('select * from chats where id=? and user_id=?', [chatId, u.id]))[0];
  if (!chat) throw fail(404, 'Чат не найден');
  const text = String(b.content || '').trim(), mode = MODE_PROMPT[b.mode] ? b.mode : 'fast';
  const st = JSON.parse(u.settings || '{}');
  const model = String(b.model || st.model || models()[0]);
  if (!text) throw fail(400, 'Напишите сообщение');
  if (text.length > P.maxChars) throw fail(413, `Сообщение длиннее лимита тарифа (${P.maxChars} символов)`);
  if (mode === 'thinking' && !P.thinking) throw fail(403, 'Режим «Думающий» недоступен на вашем тарифе');
  if (mode === 'research' && !P.research) throw fail(403, 'Режим «Исследователь» недоступен на вашем тарифе');
  if (mode === 'research' && !process.env.TAVILY_API_KEY) throw fail(503, 'Поисковый провайдер не настроен (TAVILY_API_KEY)');
  if (!modelAllowed(P, model)) throw fail(403, 'Эта модель недоступна на вашем тарифе');
  let content = text;
  if (b.file) {
    if (!P.files) throw fail(403, 'Работа с файлами недоступна на вашем тарифе');
    const ft = String(b.file.text || '').slice(0, Math.min(60000, P.maxChars * 4));
    content = `${text}\n\n📎 Файл «${String(b.file.name || 'file').slice(0, 80)}»:\n\`\`\`\n${ft}\n\`\`\``;
  }
  const pv = provider(); if (!pv) throw fail(503, 'ИИ-провайдер не настроен на сервере');
  const day = new Date().toISOString().slice(0, 10);
  const used = (await db.q('select count from usage_daily where user_id=? and day=?', [u.id, day]))[0];
  if (used && used.count >= P.msgPerDay) throw fail(429, `Дневной лимит сообщений исчерпан (${P.msgPerDay})`);
  await db.q('insert into usage_daily(user_id,day,count) values(?,?,1) on conflict(user_id,day) do update set count=usage_daily.count+1', [u.id, day]);

  const hist = (await db.q('select role,content from messages where chat_id=? order by created desc, id desc limit ?', [chatId, mode === 'thinking' ? 30 : 12])).reverse();
  await db.q('insert into messages(id,chat_id,role,content,mode,created) values(?,?,?,?,?,?)', [rid(), chatId, 'user', content, mode, now()]);
  if (!chat.title) await db.q('update chats set title=? where id=?', [text.slice(0, 48), chatId]);
  await db.q('update chats set updated=? where id=?', [now(), chatId]);

  let sys = `Ты — DDSHA AI, ассистент платформы DDSHA. Ты работаешь на внешней языковой модели «${model}» стороннего провайдера; собственную модель DDSHA не обучали — не утверждай обратного. Отвечай на языке пользователя, будь честным, не проси пароли и коды. Используй Markdown, код — в блоках.\n${MODE_PROMPT[mode]}`;
  if (st.memory !== false) {
    const mem = await db.q('select text from memories where user_id=? order by created desc limit 30', [u.id]);
    if (mem.length) sys += '\nПамять о пользователе (разрешено им):\n' + mem.map(m => '- ' + m.text).join('\n');
  }
  const note = await setting('system_note'); if (note) sys += '\n' + note.slice(0, 1000);

  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', 'X-Accel-Buffering': 'no', Connection: 'keep-alive' });
  const ev = o => { if (!res.writableEnded) res.write('data: ' + JSON.stringify(o) + '\n\n'); };
  const ac = new AbortController(); res.on('close', () => ac.abort());
  let full = '', sources = [];
  try {
    const messages = [{ role: 'system', content: sys }, ...hist];
    if (mode === 'research') {
      sources = await tavily(text);
      messages.push({ role: 'system', content: 'Источники:\n' + sources.map((s, i) => `[${i + 1}] ${s.title} (${s.url})\n${s.content}`).join('\n\n') });
    }
    messages.push({ role: 'user', content });
    const r = await fetch(pv.base + '/chat/completions', { method: 'POST', signal: ac.signal, headers: { Authorization: 'Bearer ' + pv.key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, messages, stream: true, max_tokens: mode === 'thinking' ? 2500 : mode === 'research' ? 1800 : 800, temperature: mode === 'thinking' ? 0.3 : 0.7 }) });
    if (!r.ok) { console.error('AI error', r.status, (await r.text()).slice(0, 300)); throw new Error('Провайдер ИИ вернул ошибку ' + r.status); }
    const dec = new TextDecoder(); let buf = '';
    for await (const ch of r.body) {
      buf += dec.decode(ch, { stream: true }); let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith('data:')) continue;
        const d = line.slice(5).trim(); if (d === '[DONE]') continue;
        try { const t = JSON.parse(d).choices?.[0]?.delta?.content; if (t) { full += t; ev({ t }); } } catch {}
      }
    }
    if (sources.length) { const s = '\n\n**Источники:**\n' + sources.map((x, i) => `${i + 1}. ${x.title} — ${x.url}`).join('\n'); full += s; ev({ t: s }); }
    if (!full) throw new Error('Модель не вернула текст');
    ev({ done: true });
  } catch (e) {
    if (e.name !== 'AbortError') { console.error('stream:', e.message); ev({ error: e.message || 'Ошибка ИИ' }); }
  } finally {
    if (full) await db.q('insert into messages(id,chat_id,role,content,mode,created) values(?,?,?,?,?,?)', [rid(), chatId, 'assistant', full, mode, now()]);
    if (!res.writableEnded) res.end();
  }
}

// ---------- API ----------
const OPEN = new Set(['POST /api/register', 'POST /api/login', 'POST /api/forgot', 'POST /api/reset', 'GET /api/health']);
async function api(req, res, url) {
  const m = req.method, p = url.pathname, key = m + ' ' + p, ip = ipOf(req);
  if (key === 'GET /api/health') { await db.q('select 1 as ok'); return send(res, 200, { ok: true, db: db.kind }); }
  if (m !== 'GET' && m !== 'HEAD') {
    const o = req.headers.origin; if (o) { let h; try { h = new URL(o).host; } catch {} if (h !== req.headers.host) throw fail(403, 'Недопустимый источник запроса'); }
  }
  if (!limit('api:' + ip, 300, 6e4)) throw fail(429, 'Слишком много запросов');
  let b = {}; if (m === 'POST' || m === 'PATCH' || m === 'PUT') b = await body(req);

  if (key === 'POST /api/register') {
    if (!limit('reg:' + ip, 10, 36e5)) throw fail(429, 'Слишком много регистраций, попробуйте позже');
    if (await setting('registration_open', '1') !== '1') throw fail(403, 'Регистрация временно закрыта');
    const username = String(b.username || '').trim(), email = String(b.email || '').trim().toLowerCase(), pw = String(b.password || '');
    if (!/^[\p{L}\p{N}_.-]{3,24}$/u.test(username)) throw fail(400, 'Имя: 3–24 символа (буквы, цифры, _ . -)');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 120) throw fail(400, 'Некорректный email');
    if (pw.length < 8 || pw.length > 200) throw fail(400, 'Пароль: минимум 8 символов');
    if (pw !== String(b.password2 || '')) throw fail(400, 'Пароли не совпадают');
    if ((await db.q('select 1 as x from users where email=?', [email]))[0]) throw fail(409, 'Этот email уже зарегистрирован');
    if ((await db.q('select 1 as x from users where username_lc=?', [username.toLowerCase()]))[0]) throw fail(409, 'Это имя уже занято');
    const id = rid();
    // роль и тариф НИКОГДА не берутся из запроса
    try { await db.q('insert into users(id,username,username_lc,email,pass,created) values(?,?,?,?,?,?)', [id, username, username.toLowerCase(), email, await hashPass(pw), now()]); }
    catch { throw fail(409, 'Имя или email уже заняты'); }
    await newSession(res, id);
    const u = (await db.q('select * from users where id=?', [id]))[0];
    return send(res, 201, { user: pub(u) });
  }
  if (key === 'POST /api/login') {
    const email = String(b.email || '').trim().toLowerCase();
    if (!limit('login:' + ip, 30, 9e5) || !limit('loginE:' + email, 8, 9e5)) throw fail(429, 'Слишком много попыток входа. Подождите 15 минут.');
    const u = (await db.q('select * from users where email=?', [email]))[0];
    const ok = u ? await checkPass(String(b.password || ''), u.pass) : (await hashPass('x'), false);
    if (!ok) throw fail(401, 'Неверный email или пароль');
    if (u.status === 'blocked') throw fail(403, 'Аккаунт заблокирован');
    await newSession(res, u.id);
    return send(res, 200, { user: pub(u) });
  }
  if (key === 'POST /api/forgot') {
    const email = String(b.email || '').trim().toLowerCase();
    if (limit('forgot:' + ip, 5, 36e5) && limit('forgotE:' + email, 3, 36e5)) {
      const u = (await db.q('select * from users where email=?', [email]))[0];
      if (u && u.status !== 'blocked') {
        const t = crypto.randomBytes(32).toString('base64url');
        await db.q('insert into resets(id,user_id,expires) values(?,?,?)', [sha(t), u.id, now() + 36e5]);
        const base = (process.env.PUBLIC_URL || `https://${req.headers.host}`).replace(/\/$/, '');
        const sent = await sendMail(u.email, 'DDSHA AI — восстановление пароля', `<p>Для смены пароля перейдите по ссылке (действует 1 час):</p><p><a href="${base}/?reset=${t}">${base}/?reset=${t}</a></p><p>Если это были не вы — проигнорируйте письмо.</p>`);
        if (!sent) console.warn('Почта не настроена (RESEND_API_KEY/MAIL_FROM): письмо восстановления не отправлено');
      }
    }
    return send(res, 200, { ok: true, message: 'Если такой email зарегистрирован, мы отправили письмо со ссылкой.' });
  }
  if (key === 'POST /api/reset') {
    if (!limit('reset:' + ip, 10, 36e5)) throw fail(429, 'Слишком много попыток');
    const pw = String(b.password || ''); if (pw.length < 8 || pw.length > 200) throw fail(400, 'Пароль: минимум 8 символов');
    if (pw !== String(b.password2 || '')) throw fail(400, 'Пароли не совпадают');
    const r = (await db.q('select * from resets where id=? and expires>?', [sha(String(b.token || '')), now()]))[0];
    if (!r) throw fail(400, 'Ссылка недействительна или устарела');
    await db.q('update users set pass=? where id=?', [await hashPass(pw), r.user_id]);
    await db.q('delete from resets where user_id=?', [r.user_id]); await db.q('delete from sessions where user_id=?', [r.user_id]);
    return send(res, 200, { ok: true });
  }

  // ---- ниже — только с серверной проверкой сессии ----
  const u = await sessionUser(req);
  if (!u) throw fail(401, 'Требуется вход');
  if (u.status === 'blocked') throw fail(403, 'Аккаунт заблокирован');
  const plans = await getPlans(), P = plans[effPlanId(u)] || DEFAULT_PLANS.free;
  let mt;

  if (key === 'POST /api/logout') { const t = cookies(req).ddsha_sid; await db.q('delete from sessions where id=?', [sha(t)]); setCookie(res, '', 0); return send(res, 200, { ok: true }); }
  if (key === 'GET /api/me') return send(res, 200, { user: pub(u, P), plan: P, models: models().filter(x => modelAllowed(P, x)), allModels: models(), features: { ai: !!provider(), research: !!process.env.TAVILY_API_KEY, mail: !!process.env.RESEND_API_KEY }, usedToday: (await db.q('select count from usage_daily where user_id=? and day=?', [u.id, new Date().toISOString().slice(0, 10)]))[0]?.count || 0 });
  if (key === 'PATCH /api/me/settings') {
    const st = JSON.parse(u.settings || '{}');
    if (typeof b.memory === 'boolean') st.memory = b.memory;
    if (b.model && models().includes(b.model) && modelAllowed(P, b.model)) st.model = b.model;
    await db.q('update users set settings=? where id=?', [JSON.stringify(st), u.id]);
    return send(res, 200, { settings: st });
  }
  if (key === 'GET /api/chats') return send(res, 200, { chats: await db.q('select id,title,updated from chats where user_id=? order by updated desc limit 200', [u.id]) });
  if (key === 'POST /api/chats') { const id = rid(); await db.q('insert into chats(id,user_id,title,created,updated) values(?,?,?,?,?)', [id, u.id, '', now(), now()]); return send(res, 201, { id }); }
  if ((mt = p.match(/^\/api\/chats\/([\w]+)$/))) {
    if (m === 'PATCH') { const t = String(b.title || '').trim().slice(0, 80); if (!t) throw fail(400, 'Пустое название'); await db.q('update chats set title=? where id=? and user_id=?', [t, mt[1], u.id]); return send(res, 200, { ok: true }); }
    if (m === 'DELETE') { if ((await db.q('select 1 as x from chats where id=? and user_id=?', [mt[1], u.id]))[0]) { await db.q('delete from messages where chat_id=?', [mt[1]]); await db.q('delete from chats where id=?', [mt[1]]); } return send(res, 200, { ok: true }); }
  }
  if ((mt = p.match(/^\/api\/chats\/([\w]+)\/messages$/)) && m === 'GET') {
    if (!(await db.q('select 1 as x from chats where id=? and user_id=?', [mt[1], u.id]))[0]) throw fail(404, 'Чат не найден');
    return send(res, 200, { messages: await db.q('select id,role,content,mode from messages where chat_id=? order by created, id', [mt[1]]) });
  }
  if ((mt = p.match(/^\/api\/chats\/([\w]+)\/stream$/)) && m === 'POST') {
    if (!limit('chat:' + u.id, 30, 6e4)) throw fail(429, 'Слишком часто. Подождите минуту.');
    return streamChat(req, res, u, mt[1], b);
  }
  if (key === 'GET /api/memory') return send(res, 200, { items: await db.q('select id,text from memories where user_id=? order by created desc', [u.id]) });
  if (key === 'POST /api/memory') {
    const t = String(b.text || '').trim().slice(0, 300); if (!t) throw fail(400, 'Пустая запись');
    if ((await db.q('select id from memories where user_id=?', [u.id])).length >= 100) throw fail(400, 'Лимит памяти: 100 записей');
    const id = rid(); await db.q('insert into memories(id,user_id,text,created) values(?,?,?,?)', [id, u.id, t, now()]); return send(res, 201, { id });
  }
  if ((mt = p.match(/^\/api\/memory\/([\w]+)$/)) && m === 'DELETE') { await db.q('delete from memories where id=? and user_id=?', [mt[1], u.id]); return send(res, 200, { ok: true }); }

  // ---- админ-API: всегда проверка роли в БД, а не в браузере ----
  if (p.startsWith('/api/admin/')) {
    if (u.role !== 'owner') throw fail(403, 'Недостаточно прав');
    if (!limit('adm:' + u.id, 120, 6e4)) throw fail(429, 'Слишком много запросов');
    const today = new Date().toISOString().slice(0, 10), one = async (s, a = []) => (await db.q(s, a))[0].c;
    if (key === 'GET /api/admin/stats') return send(res, 200, {
      users: await one('select count(*) as c from users'), blocked: await one("select count(*) as c from users where status='blocked'"),
      chats: await one('select count(*) as c from chats'), messages: await one('select count(*) as c from messages'),
      messagesToday: (await db.q('select coalesce(sum(count),0) as c from usage_daily where day=?', [today]))[0].c,
      byPlan: await db.q('select plan, count(*) as c from users group by plan'), db: db.kind });
    if (key === 'GET /api/admin/users') {
      const s = String(url.searchParams.get('q') || '').trim().toLowerCase().slice(0, 80), like = `%${s}%`;
      const rows = s ? await db.q('select id,username,email,role,plan,plan_until,status,created from users where id=? or lower(username) like ? or email like ? order by created desc limit 50', [s, like, like])
                     : await db.q('select id,username,email,role,plan,plan_until,status,created from users order by created desc limit 50');
      return send(res, 200, { users: rows });
    }
    if ((mt = p.match(/^\/api\/admin\/users\/(\w+)$/)) && m === 'GET') {
      const t = (await db.q('select * from users where id=?', [mt[1]]))[0]; if (!t) throw fail(404, 'Пользователь не найден');
      const o = pub(t, plans[effPlanId(t)]); o.chats = await one('select count(*) as c from chats where user_id=?', [t.id]);
      o.usedToday = (await db.q('select count from usage_daily where user_id=? and day=?', [t.id, today]))[0]?.count || 0; return send(res, 200, { user: o });
    }
    if ((mt = p.match(/^\/api\/admin\/users\/(\w+)\/(plan|block)$/)) && m === 'POST') {
      const t = (await db.q('select * from users where id=?', [mt[1]]))[0]; if (!t) throw fail(404, 'Пользователь не найден');
      if (t.role === 'owner') throw fail(400, 'Владельца нельзя изменять через панель');
      if (mt[2] === 'plan') {
        const plan = String(b.plan || ''); if (!plans[plan]) throw fail(400, 'Неизвестный тариф');
        const days = b.days === null || b.days === '' || b.days === undefined ? null : Number(b.days);
        if (days !== null && !(days > 0 && days <= 3650)) throw fail(400, 'Срок: 1–3650 дней');
        const until = plan === 'free' || days === null ? null : now() + days * DAY;
        await db.q('update users set plan=?, plan_until=? where id=?', [plan, until, t.id]);
        await audit(u.id, plan === 'free' ? 'plan.revoke' : 'plan.grant', t.id, { from: t.plan, plan, until });
      } else {
        const blocked = !!b.blocked; await db.q('update users set status=? where id=?', [blocked ? 'blocked' : 'active', t.id]);
        if (blocked) await db.q('delete from sessions where user_id=?', [t.id]);
        await audit(u.id, blocked ? 'user.block' : 'user.unblock', t.id, { reason: String(b.reason || '').slice(0, 200) });
      }
      return send(res, 200, { ok: true });
    }
    if (key === 'GET /api/admin/plans') return send(res, 200, { plans: Object.values(plans) });
    if ((mt = p.match(/^\/api\/admin\/plans\/(\w+)$/)) && m === 'PUT') {
      const cur = plans[mt[1]]; if (!cur) throw fail(404, 'Тариф не найден');
      const n = v => Math.max(0, Math.min(1e7, Math.floor(Number(v) || 0)));
      const cfg = { msgPerDay: n(b.msgPerDay), maxChars: Math.max(100, n(b.maxChars)), models: Array.isArray(b.models) ? b.models.map(String).slice(0, 50) : [], files: !!b.files, search: !!b.search, thinking: !!b.thinking, research: !!b.research, imagesPerDay: n(b.imagesPerDay), videosPerDay: n(b.videosPerDay) };
      await db.q('update plans set cfg=? where id=?', [JSON.stringify(cfg), mt[1]]);
      await audit(u.id, 'plan.config', mt[1], cfg); return send(res, 200, { ok: true });
    }
    if (key === 'GET /api/admin/audit') return send(res, 200, { items: await db.q('select a.id,a.action,a.target,a.detail,a.created,u.username as actor from audit a left join users u on u.id=a.actor order by a.created desc limit 200') });
    if (key === 'GET /api/admin/settings') return send(res, 200, { registration_open: await setting('registration_open', '1') === '1', system_note: await setting('system_note') });
    if (key === 'PUT /api/admin/settings') {
      for (const [k, v] of [['registration_open', b.registration_open ? '1' : '0'], ['system_note', String(b.system_note || '').slice(0, 1000)]])
        await db.q('insert into settings(k,v) values(?,?) on conflict(k) do update set v=excluded.v', [k, v]);
      await audit(u.id, 'settings.update', null, { registration_open: !!b.registration_open }); return send(res, 200, { ok: true });
    }
  }
  throw fail(404, 'Маршрут не найден');
}

// ---------- Статика и сервер ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
function serveStatic(req, res, url) {
  let f = decodeURIComponent(url.pathname); if (f === '/') f = '/index.html'; if (f === '/admin') f = '/admin.html';
  const full = path.join(PUB, path.normalize(f));
  if (!full.startsWith(PUB + path.sep) || !fs.existsSync(full) || !fs.statSync(full).isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Не найдено'); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(full).pipe(res);
}
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'DENY'); res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  if (PROD) res.setHeader('Strict-Transport-Security', 'max-age=15552000');
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) await api(req, res, url); else serveStatic(req, res, url);
  } catch (e) {
    const code = Number.isInteger(e.code) && e.code >= 400 && e.code < 600 ? e.code : 500;
    if (code === 500) console.error(e);
    if (res.headersSent) { if (!res.writableEnded) res.end(); return; }
    send(res, code, { error: code === 500 ? 'Внутренняя ошибка сервера' : e.message });
  }
});

async function bootstrap() {
  await db.init();
  for (const [id, c] of Object.entries(DEFAULT_PLANS)) { const { name, ...cfg } = c; await db.q('insert into plans(id,name,cfg) values(?,?,?) on conflict(id) do nothing', [id, name, JSON.stringify(cfg)]); }
  // Первый владелец — только из переменных окружения сервера, только если владельца ещё нет
  const { OWNER_USERNAME: un, OWNER_EMAIL: em, OWNER_PASSWORD: pw } = process.env;
  if (!(await db.q("select 1 as x from users where role='owner'"))[0]) {
    if (un && em && pw && pw.length >= 10) {
      const email = em.trim().toLowerCase();
      const ex = (await db.q('select id from users where email=?', [email]))[0];
      if (ex) await db.q("update users set role='owner', plan='all' where id=?", [ex.id]);
      else await db.q("insert into users(id,username,username_lc,email,pass,role,plan,created) values(?,?,?,?,?,'owner','all',?)", [rid(), un.trim(), un.trim().toLowerCase(), email, await hashPass(pw), now()]);
      console.log('Создан аккаунт владельца:', email);
    } else console.warn('Владелец не создан: задайте OWNER_USERNAME, OWNER_EMAIL, OWNER_PASSWORD (≥10 символов)');
  }
  server.listen(PORT, '0.0.0.0', () => console.log(`DDSHA AI слушает порт ${PORT} (БД: ${db.kind}, ИИ: ${provider() ? 'настроен' : 'НЕ настроен'})`));
}
bootstrap().catch(e => { console.error('Не удалось запустить сервер:', e); process.exit(1); });
process.on('SIGTERM', () => server.close(() => process.exit(0)));
