'use strict';
// Единый слой БД: PostgreSQL (DATABASE_URL, Render) или SQLite-файл (node:sqlite, локальная разработка).
// SQL написан с плейсхолдерами "?" и совместим с обоими.
const SCHEMA = `
create table if not exists users(id text primary key, username text not null, username_lc text not null unique, email text not null unique,
  pass text not null, role text not null default 'user', plan text not null default 'free', plan_until bigint, status text not null default 'active',
  settings text not null default '{}', created bigint not null);
create table if not exists sessions(id text primary key, user_id text not null, expires bigint not null, created bigint not null);
create table if not exists resets(id text primary key, user_id text not null, expires bigint not null);
create table if not exists chats(id text primary key, user_id text not null, title text not null, created bigint not null, updated bigint not null);
create table if not exists messages(id text primary key, chat_id text not null, role text not null, content text not null, mode text, created bigint not null);
create table if not exists memories(id text primary key, user_id text not null, text text not null, created bigint not null);
create table if not exists plans(id text primary key, name text not null, cfg text not null);
create table if not exists audit(id text primary key, actor text not null, action text not null, target text, detail text, created bigint not null);
create table if not exists settings(k text primary key, v text not null);
create table if not exists usage_daily(user_id text not null, day text not null, count integer not null default 0, primary key(user_id, day));
create index if not exists i_chats_user on chats(user_id, updated);
create index if not exists i_msgs_chat on messages(chat_id, created);
create index if not exists i_sess_user on sessions(user_id);
create index if not exists i_mem_user on memories(user_id);
`;
let q, exec; const db = { kind: '' };
db.init = async () => {
  if (process.env.DATABASE_URL) {
    const pg = require('pg'); pg.types.setTypeParser(20, Number);
    const url = process.env.DATABASE_URL;
    const ssl = process.env.PGSSL === 'disable' ? false : (process.env.PGSSL === 'require' || /render\.com|neon\.tech|supabase/.test(url)) ? { rejectUnauthorized: false } : false;
    const pool = new pg.Pool({ connectionString: url, ssl, max: 8 });
    q = async (sql, p = []) => { let n = 0; return (await pool.query(sql.replace(/\?/g, () => '$' + (++n)), p)).rows; };
    exec = async s => { await pool.query(s); };
    db.kind = 'postgres';
  } else {
    const { DatabaseSync } = require('node:sqlite');
    const d = new DatabaseSync(process.env.SQLITE_PATH || './data.db');
    d.exec('pragma journal_mode=WAL');
    q = async (sql, p = []) => { const st = d.prepare(sql); return /^\s*(select|with)/i.test(sql) ? st.all(...p) : (st.run(...p), []); };
    exec = async s => { d.exec(s); };
    db.kind = 'sqlite';
  }
  await exec(SCHEMA);
};
db.q = (...a) => q(...a);
module.exports = db;
